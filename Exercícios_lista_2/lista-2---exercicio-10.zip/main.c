
#include <stdio.h>
#include <math.h>

int main()
{
   float n;
   
   printf("N: ");
   scanf("%f", &n);
   
   if(n >= 0)
   {
       n = sqrt(n);
   }
   
   else
   {
       n = pow(n, 2);
   }
   
   printf("%f", n);
   
   
   //ENTRADAS: float n
   //SAIDA: float n ao quadrado ou float raiz de n
}
