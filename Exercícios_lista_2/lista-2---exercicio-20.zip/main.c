
#include <stdio.h>

int main()
{
    float prova1, prova2, trabalho, media;
    int faltas;
    
    printf("Nota da prova 1: ");
    scanf("%f", &prova1);
    
    printf("Nota da prova 2: ");
    scanf("%f", &prova2);
    
    printf("Nota do trabalho: ");
    scanf("%f", &trabalho);
    
    printf("Qtde de faltas: ");
    scanf("%d", &faltas);
    
    media = ((3 * prova1) + (5 * prova2) + (2 * trabalho)) / 10;
    
    if(faltas >= 15)
    {
        printf("REPROVADO POR FALTA");
    }
    
    else
    {
    
     if(media >= 7.0)
    {
        printf("APROVADO");
    }
    
    else if(media < 4.0)
    {
        printf("REPROVADO POR NOTA");
    }
    
    else
    {
        printf("EM PROVA FINAL");
    }
    
    } 
    
    //ENTRADAS: float prova1, prova2, trabalho e int faltas
    //SAIDA: mensagem informando a situacao
    
}
