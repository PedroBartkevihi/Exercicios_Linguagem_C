#include <stdio.h>

int main()
{
    float temperatura, fahrenheit, celsius;
    char escala;
    
    
    printf("digite a escala (c ou f): ");
    scanf("%c", &escala);
    
    printf("digite a temperatura: ");
    scanf("%f", &temperatura);
    
    
    
    
    if(escala == 'c')
    {
        fahrenheit = 1.8 * temperatura + 32;
        printf("temperatura em fahrenheit: %.2f", fahrenheit);
    }
    
    else if(escala == 'f')
    {
        celsius = (temperatura - 32) * 0.5;
        printf("temperatura em celsius: %.2f", celsius);
    }
    
    
    //ENTRADAS: char escala e float temperatura
    //SAIDA: float celsius ou float fahrenheit
    
    
    
}
