
#include <stdio.h>

int main()
{
   float altura;
   int idade;
   
   printf("Altura: ");
   scanf("%f", &altura);
   
   printf("Idade: ");
   scanf("%d", &idade);
   
   if(altura >= 1.8 && idade < 18)
   {
       printf("SELECIONADO");
   }
   
   else
   {
       printf("NAO SELECIONADO");
   }
}


//ENTRADAS: float altura e int idade
//SAIDA: mensagem informando SELECIONADO ou NAO SELECIONADO
