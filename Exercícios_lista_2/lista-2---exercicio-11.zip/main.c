
#include <stdio.h>
#include <math.h>

int main()
{
  int n, parte1, parte2;
  
  printf("N: ");
  scanf("%d", &n);
  
  if(n < 1000 || n > 9999)
  {
      printf("INSIRA UM NUMERO DE 4 DIGITOS");
  }
  
  else
  {
  parte1 = n / 100;
  parte2 = n % 100;
  
  
  if((pow((parte1 + parte2), 2)) == n)
  
  {
      printf("O NUMERO TEM A CARACTERISTICA");
  }
  
  else
  {
      printf("O NUMERO NAO TEM A CARACTERISTICA");
  }
  
  } 
  //ENTRADAS: int n
  //SAIDA: mensagem informando se tem a caracteristica ou nao
  
}
