#include <stdio.h>

int main()
{
    
    float bruto, liquido, imposto, horas, valor_hora;
    printf("Horas trabalhadas: ");
    scanf("%f", &horas);
    
    printf("Valor hora: ");
    scanf("%f", &valor_hora);
    
    bruto = valor_hora * horas;
    
    if(bruto <= 1900)
    {
        imposto = 0;
    }
    
    else if(bruto > 1900 && bruto < 4300)
    {
        imposto = 0.10;
    }
    
    else if(bruto > 4300 && bruto <= 5800)
    {
        imposto = 0.15;
    }
    
    else if(bruto > 5800)
    {
        imposto = 0.275;
    }
    
    liquido = bruto - (bruto * imposto);
    
    printf("Salario bruto: %.2f\n", bruto);
    printf("Salario liquido: %.2f", liquido);
    
    
    //ENTRADAS: float valor_hora e float horas trabalhadas
    //SAIDA: float salario bruto e float salario liquido
    
}
