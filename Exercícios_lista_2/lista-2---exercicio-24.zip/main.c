
#include <stdio.h>

int main()
{
    float horas, valor_hora, salario_semanal;
    
    printf("Horas trabalhadas por semana: ");
    scanf("%f", &horas);
    
    if(horas <= 40)
    {
        valor_hora = 15;
        salario_semanal = valor_hora * horas;
    }
    
    else
    {
        salario_semanal = (horas - 40) * 21 + 600;
    }
    
    printf("salario semanal: %.2f", salario_semanal);
    
    
    //ENTRADAS: float horas por semana
    //SAIDA: float salario semanal
}
    

