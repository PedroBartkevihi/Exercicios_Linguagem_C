#include <stdio.h>

int main()
{
   float valor, parcela, valor_final;
   int condicao;
   
   printf("Valor da compra: ");
   scanf("%f", &valor);
   
   printf("Condicao de pagamento:\n1- A vista (dinheiro ou cheque)\n2- A vista (cartao de credito)\n3- Parcelado em duas vezes\n4- Parcelado em 3 vezes");
   scanf("%d", &condicao);
   
   switch(condicao)
   {
       case 1:
       valor_final = valor * 0.9;
       break;
       
       case 2:
       valor_final = valor * 0.95;
       break;
       
       case 3:
       valor_final = valor;
       parcela = valor / 2;
       break;
       
       case 4: 
       valor_final = valor * 1.1;
       parcela = (valor * 1.1) / 3;
       break;
       
       default:
       printf("ESCOLHA UMA CONDICAO EXISTENTE");
       break;
       
       
   }
   
   printf("Valor final: %.2f\n", valor_final);
   
   if(condicao == 3 || condicao == 4)
   {
       
   printf("Valor parcelas: %.2f", parcela);
   
   }
 
   
   //ENTRADAS: float valor e int condicao de pagamento
   //SAIDA: float valor final e float parcelas
   
   
   
}
