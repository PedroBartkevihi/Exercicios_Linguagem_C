
#include <stdio.h>

int main()
{
    float salario, financiamento;
    
    
    printf("Salario: ");
    scanf("%f", &salario);
    
    printf("Financiamento: ");
    scanf("%f", &financiamento);
    
    if(financiamento <= 5 * salario)
    {
        printf("FINANCIAMENTO CONCEDIDO");
    }
    
    else
    {
        printf("FINANCIAMENTO NEGADO");
    }
    
    
    //ENTRADAS: float salario e float financiamento
    //SAIDA: mensagem informando financiamento concedido ou negado
}
