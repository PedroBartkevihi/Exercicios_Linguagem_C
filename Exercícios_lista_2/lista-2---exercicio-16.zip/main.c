
#include <stdio.h>

int main()
{
    float nota;
    char conceito;
    
    printf("Nota: ");
    scanf("%f", &nota);
    
    if(nota > 9.0 && nota < 10.0)
    {
        conceito = 'A';
        printf("Conceito: %c", conceito);
    }
    
    else if(nota < 8.9 && nota > 7.0)
    {
        conceito = 'B';
        printf("Conceito: %c", conceito);
    }
    
    else if(nota < 6.9 && nota > 5.0)
    {
        conceito = 'C';
        printf("Conceito: %c", conceito);
    }
    
    else if(nota < 5.0)
    {
        conceito = 'D';
        printf("Conceito: %c", conceito);
    }
    
    else
    {
        printf("NOTA INVALIDA");
    }
    
    
    //ENTRADAS: float nota
    //SAIDA: char conceito
    
    
    
    
    
    
}
