
#include <stdio.h>

int main()
{
    int n;
    
    
    printf("N: ");
    scanf("%d", &n);
    
    if(n % 6 == 0)
    {
        printf("DIVISIVEL POR 6");
    }
    
    else
    {
        printf("NAO DIVISIVEL POR 6");
    }
    
    
    //ENTRADAS: int n
    //SAIDA: mensagem dizendo se e divisivel ou nao
}
