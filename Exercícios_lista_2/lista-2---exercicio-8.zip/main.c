
#include <stdio.h>

int main()
{
   int n;
   
   printf("N: ");
   scanf("%d", &n);
   
   if(n == 5)
   {
       printf("IGUAL A 5");
   }
   
   else if(n == 200)
   {
       printf("IGUAL A 200");
   }
   
   else if(n == 400)
   {
       printf("IGUAL A 400");
   }
   
   else if(n >= 500 && n <= 1000)
   {
       printf("DENTRO DO INTERVALO");
   }
   
   else
   {
       printf("NENHUMA DAS ANTERIORES");
   }
}













