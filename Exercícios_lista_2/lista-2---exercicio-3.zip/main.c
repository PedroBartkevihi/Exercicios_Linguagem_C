
#include <stdio.h>

int main()
{
     int n;
    
    printf("N: ");
    scanf("%d", &n);
    
    if(n % 3 == 0 || n % 7 == 0)
    {
        printf("NUMERO DIVISIVEL POR 3 OU 7");
    }
    
    else
    {
        printf("NUMERO NAO DIVISIVEL POR 3 NEM 7");
    }
    
    
    //ENTRADAS: int n
    //SAIDA: mensagem informando se é divisivel por 3 ou 7 ou nao
}
