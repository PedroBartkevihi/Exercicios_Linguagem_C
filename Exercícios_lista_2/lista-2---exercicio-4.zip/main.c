
#include <stdio.h>

int main()
{
   int n, k;
    
    printf("N: ");
    scanf("%d", &n);
    
    printf("K: ");
    scanf("%d", &k);
    
    if(n % k == 0)
    {
        printf("%d É DIVISIVEL POR %d", n, k);
    }
    
    else
    {
        printf("%d NAO É DIVISIVEL POR %d", n, k);
    }
    
    
    //ENTRADAS: int n e int k
    //SAIDA: mensagem informando se n divisivel por k ou nao
   
   
}
