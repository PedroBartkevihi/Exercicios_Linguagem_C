
#include <stdio.h>

int main()
{
    int a, b, c, menor, maior;
    
    
    printf("A: ");
    scanf("%d", &a);
    
    printf("B: ");
    scanf("%d", &b);
    
    printf("C: ");
    scanf("%d", &c);
    
    if(a > b)
    {
        if(a > c)
        {
            maior = a;
            if(b < c)
            {
                menor = b;
            }
            
            else if(c < b)
            {
                menor = c;
            }
        }
    }
    
    if(b > a)
    {
        if(b > c)
        {
            maior = b;
            if(a < c)
            {
                menor = a;
            }
            
            else if(c < a)
            {
                menor = c;
            }
        }
    }
    
    
    
    
    if(c > a)
    {
        if(c > b)
        {
            maior = c;
            if(b < a)
            {
                menor = b;
            }
            
            else if(a < b)
            {
                menor = a;
            }
            
        }
    }
    
    printf("maior numero: %d\n", maior);
    printf("menor numero: %d", menor);
    
    
}



















