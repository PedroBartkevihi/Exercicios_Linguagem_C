#include <stdio.h>

int main()
{
  int nascimento, atual, idade;
  
  printf("Digite o ano de nascimento da pessoa: ");
  scanf("%d", &nascimento);
  
  printf("Digite o ano atual: ");
  scanf("%d", &atual);
  
  idade = atual - nascimento;
  
  if(idade >= 0 && idade <= 3)
  {
      printf("BEBE");
  }
  
  else if(idade >= 4 && idade <= 10)
  {
      printf("CRIANCA");
  }
  
  else if(idade >= 11 && idade <= 18)
  {
      printf("ADOLESCENTE");
  }
  
  else if(idade >= 19 && idade <= 60)
  {
      printf("ADULTO");
  }
  
  else if(idade >= 61)
  {
      printf("IDOSO");
  }
  
  
  
  //ENTRADAS: int ano atual e int ano nascimento
  //SAIDA: mensagem informando idade
  
  
  
  
  
}
