#include <stdio.h>
#include <math.h>

int main()
{
    float x1, x2, y1, y2, p1, p2, distancia;
    
    printf("X1: ");
    scanf("%f", &x1);
    
    printf("X2: ");
    scanf("%f", &x2);
    
    printf("Y1: ");
    scanf("%f", &y1);
    
    printf("Y2: ");
    scanf("%f", &y2);
    
    p1 = (x1 - x2);
    p2 = (y1 - y2);
    
    distancia = sqrt(pow(p1, 2) + pow(p2, 2));
    
    printf("distancia dos pontos: %.2f", distancia);
    
    
    
    
    //ENTRADAS: float x1, x2, y1, y2
    //SAIDA: float distancia
    
}
