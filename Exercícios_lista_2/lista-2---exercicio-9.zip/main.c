
#include <stdio.h>

int main()
{
    int qtd_pecas, tipo_peca;
    float valor_peca, subtotal, valor_final;
    
    
    printf("Insira a quantidade de pecas: ");
    scanf("%d", &qtd_pecas);
    
    printf("Insira o tipo de peca comprada: ");
    scanf("%d", &tipo_peca);
    
    switch(tipo_peca)
    {
        case 1:
        valor_peca = 10;
        break;
        
        case 2:
        valor_peca = 15;
        break;
        
        case 3:
        valor_peca = 20;
        break;
        
        default:
        printf("tipo de peca inexistente");
        break;
    }
    
    subtotal = valor_peca * qtd_pecas;
    
    if(subtotal > 200)
    {
        valor_final = subtotal * 0.8;
    }
    else
    {
        valor_final = subtotal;
    }
    
    printf("Valor final: %.2f", valor_final);
    
    
    
    
    //ENTRADAS: int qtd de pecas, int tipo de peca
    //SAIDA: float valor final da compra
    
}
